def minimumScore(nums, k):
    minimum = float('inf')
    maximum = float('-inf')
    for num in nums:
        minimum = min(minimum, num)
        maximum = max(maximum, num)
    score = maximum - minimum
    if score == 0:
        return 0
    potential_min_score = score
    for num in nums:
        potential_new_min = min(minimum + k, num - k)
        potential_new_max = max(maximum - k, num + k)
        potential_min_score = min(potential_min_score, potential_new_max - potential_new_min)
    return potential_min_score
nums = [1]
k = 0
result = minimumScore(nums, k)
print(result)