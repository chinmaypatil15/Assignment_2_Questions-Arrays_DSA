def findLHS(Arr):
    num_freq = {}
    for num in Arr:
        num_freq[num] = num_freq.get(num, 0) + 1
    max_length = 0
    for num in num_freq:
        if num + 1 in num_freq:
            max_length = max(max_length, num_freq[num] + num_freq[num + 1])
    return max_length
Arr = [1, 3, 2, 2, 5, 2, 3, 7]
result = findLHS(Arr)
print(result)
